from django.apps import AppConfig


class ThreadedConfig(AppConfig):
    name = 'Threaded'
