from django.shortcuts import render, redirect
from django.http import HttpResponseRedirect, HttpResponse
import json
import requests
from django.http import JsonResponse
import os
import datetime
from time import gmtime, strftime

# Create your views here.
def comment(request):
    json_data = open("Threaded_comment/static/db.json") 
    data2 = json.load(json_data) # deserialises it
    return render(request,'Threaded/base.html',{'data2': data2})
    # return HttpResponse(data2)

def add_comment(request):
    if request.method == 'POST':
        # Get form values
        name = request.POST['name']
        comment = request.POST['comment']
        now=datetime.datetime.now()
        # date= now.strftime("%Y-%m-%d")
        # print(date)
        showtime = strftime("%Y-%m-%d %H:%M:%S", gmtime())
        # print("Date: "+ now.strftime("%Y-%m-%d"))
        # print(name)
        # print(comment)
        new_comment = {
            "name": name,
            "text": comment,
            "date": showtime,
            "replies": []
        } 
        if name and comment:   
            with open("Threaded_comment/static/db.json") as f: 
                data = json.load(f)
                data.append(new_comment)

            with open("Threaded_comment/static/db.json",'w') as af: 
                json.dump(data, af, indent=4,sort_keys=True, default=str)
    return redirect('comment')  
   

def get_comments(request):
    json_data = open("Threaded_comment/static/db.json") 
    data2 = json.load(json_data) 
    return HttpResponse(data2)
